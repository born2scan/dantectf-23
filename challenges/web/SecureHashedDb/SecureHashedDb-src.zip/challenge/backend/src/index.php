<?php
require_once('utils/handler.php');
$handlerInstance = new Handler();

echo $handlerInstance;
?>